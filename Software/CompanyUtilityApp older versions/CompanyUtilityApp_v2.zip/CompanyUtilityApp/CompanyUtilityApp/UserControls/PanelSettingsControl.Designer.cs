﻿namespace CompanyUtilityApp.UserControls
{
    partial class PanelSettingsControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                // Dispose the currently active action control (Register or Manual)
                if (_currentActionControl != null)
                {
                    _currentActionControl.Dispose();
                    _currentActionControl = null;
                }
                if (components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            cmbRoute = new ComboBox();
            label1 = new Label();
            panel1 = new Panel();
            txtPanelSerialNumber = new TextBox();
            label9 = new Label();
            btnManualCalibrate = new Button();
            btnRegisterIP = new Button();
            txtDescription = new TextBox();
            cmbIPAddress = new ComboBox();
            cmbPanelLocation = new ComboBox();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            pnlAction = new Panel();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // cmbRoute
            // 
            cmbRoute.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbRoute.Location = new Point(187, 41);
            cmbRoute.Name = "cmbRoute";
            cmbRoute.Size = new Size(121, 28);
            cmbRoute.TabIndex = 13;
            cmbRoute.SelectedIndexChanged += cmbRoute_SelectedIndexChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(43, 44);
            label1.Name = "label1";
            label1.Size = new Size(51, 20);
            label1.TabIndex = 2;
            label1.Text = "Route:";
            // 
            // panel1
            // 
            panel1.Controls.Add(cmbRoute);
            panel1.Controls.Add(txtPanelSerialNumber);
            panel1.Controls.Add(label9);
            panel1.Controls.Add(btnManualCalibrate);
            panel1.Controls.Add(btnRegisterIP);
            panel1.Controls.Add(txtDescription);
            panel1.Controls.Add(cmbIPAddress);
            panel1.Controls.Add(cmbPanelLocation);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1025, 279);
            panel1.TabIndex = 3;
            // 
            // txtPanelSerialNumber
            // 
            txtPanelSerialNumber.Location = new Point(195, 136);
            txtPanelSerialNumber.Name = "txtPanelSerialNumber";
            txtPanelSerialNumber.ReadOnly = true;
            txtPanelSerialNumber.Size = new Size(125, 27);
            txtPanelSerialNumber.TabIndex = 12;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(43, 136);
            label9.Name = "label9";
            label9.Size = new Size(146, 20);
            label9.TabIndex = 11;
            label9.Text = "Panel Serial Number:";
            // 
            // btnManualCalibrate
            // 
            btnManualCalibrate.Location = new Point(233, 213);
            btnManualCalibrate.Name = "btnManualCalibrate";
            btnManualCalibrate.Size = new Size(147, 29);
            btnManualCalibrate.TabIndex = 10;
            btnManualCalibrate.Text = "Calibrate Manually";
            btnManualCalibrate.UseVisualStyleBackColor = true;
            btnManualCalibrate.Click += btnManualCalibrate_Click;
            // 
            // btnRegisterIP
            // 
            btnRegisterIP.Location = new Point(43, 213);
            btnRegisterIP.Name = "btnRegisterIP";
            btnRegisterIP.Size = new Size(140, 29);
            btnRegisterIP.TabIndex = 9;
            btnRegisterIP.Text = "Calibrate Node";
            btnRegisterIP.UseVisualStyleBackColor = true;
            btnRegisterIP.Click += btnRegisterIP_Click;
            // 
            // txtDescription
            // 
            txtDescription.Location = new Point(540, 87);
            txtDescription.Multiline = true;
            txtDescription.Name = "txtDescription";
            txtDescription.ReadOnly = true;
            txtDescription.Size = new Size(422, 57);
            txtDescription.TabIndex = 8;
            // 
            // cmbIPAddress
            // 
            cmbIPAddress.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbIPAddress.FormattingEnabled = true;
            cmbIPAddress.Location = new Point(540, 41);
            cmbIPAddress.Name = "cmbIPAddress";
            cmbIPAddress.Size = new Size(151, 28);
            cmbIPAddress.TabIndex = 7;
            cmbIPAddress.SelectedIndexChanged += cmbIPAddress_SelectedIndexChanged;
            // 
            // cmbPanelLocation
            // 
            cmbPanelLocation.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbPanelLocation.FormattingEnabled = true;
            cmbPanelLocation.Location = new Point(187, 83);
            cmbPanelLocation.Name = "cmbPanelLocation";
            cmbPanelLocation.Size = new Size(151, 28);
            cmbPanelLocation.TabIndex = 6;
            cmbPanelLocation.SelectedIndexChanged += cmbPanelLocation_SelectedIndexChanged;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(396, 90);
            label4.Name = "label4";
            label4.Size = new Size(109, 40);
            label4.TabIndex = 5;
            label4.Text = "Panel Location \r\nDescription:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(396, 41);
            label3.Name = "label3";
            label3.Size = new Size(81, 20);
            label3.TabIndex = 4;
            label3.Text = "IP Address:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(43, 86);
            label2.Name = "label2";
            label2.Size = new Size(108, 20);
            label2.TabIndex = 3;
            label2.Text = "Panel Location:";
            // 
            // pnlAction
            // 
            pnlAction.Dock = DockStyle.Fill;
            pnlAction.Location = new Point(0, 279);
            pnlAction.Name = "pnlAction";
            pnlAction.Size = new Size(1025, 484);
            pnlAction.TabIndex = 4;
            pnlAction.Visible = false;
            // 
            // PanelSettingsControl
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(pnlAction);
            Controls.Add(panel1);
            Name = "PanelSettingsControl";
            Size = new Size(1025, 763);
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private ComboBox cmbRoute;
        private Label label1;
        private Panel panel1;
        private TextBox txtDescription;
        private ComboBox cmbIPAddress;
        private ComboBox cmbPanelLocation;
        private Label label4;
        private Label label3;
        private Label label2;
        private Button btnManualCalibrate;
        private Button btnRegisterIP;
        private TextBox txtPanelSerialNumber;
        private Label label9;
        private Panel pnlAction;
    }
}
