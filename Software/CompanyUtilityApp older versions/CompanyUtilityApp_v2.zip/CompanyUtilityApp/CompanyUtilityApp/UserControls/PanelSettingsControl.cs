﻿using CompanyUtilityApp.ProgramFiles;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO.Ports;
using System.Linq;
using System.Windows.Forms;

namespace CompanyUtilityApp.UserControls
{
    public partial class PanelSettingsControl : UserControl
    {
        private PanelSettingRegisterIP _registerControl;
        private PanelSettingManualCalibrate _manualControl;
        private UserControl _currentActionControl;

        private List<PanelSettingsModel> _assignedNodes = new List<PanelSettingsModel>();
        private bool _updating = false;

        // ------------------ Initialisation.
        public PanelSettingsControl()
        {
            InitializeComponent();
            PopulateRouteDropdown();

            _registerControl = new PanelSettingRegisterIP();
            _manualControl = new PanelSettingManualCalibrate();
            _registerControl.CalibrationCompleted += ActionControl_CalibrationCompleted;
            _manualControl.CalibrationCompleted += ActionControl_CalibrationCompleted;
        }

        private void PopulateRouteDropdown()
        {
            cmbRoute.Items.AddRange(new object[] { 1, 2, 3, 4 });
            cmbRoute.SelectedIndex = 0;
        }

        // ------------------ Method to update the entire panelSettings User Control.
        private void UpdateActionPanel(UserControl control)
        {
            if (_currentActionControl is PanelSettingRegisterIP prevReg)
                prevReg.Dispose();
            else if (_currentActionControl is PanelSettingManualCalibrate prevMan)
                prevMan.Dispose();

            pnlAction.Controls.Clear();
            if (control != null)
            {
                control.Dock = DockStyle.Fill;
                pnlAction.Controls.Add(control);
                pnlAction.Visible = true;

                if (cmbPanelLocation.SelectedItem is PanelSettingsModel node)
                {
                    if (control is PanelSettingRegisterIP reg) reg.SelectedNode = node;
                    else if (control is PanelSettingManualCalibrate man) man.SelectedNode = node;
                }
            }
            else
            {
                pnlAction.Visible = false;
            }
        }

        // ------------------ The next three methods: for Button Logic.
        private void btnRegisterIP_Click(object sender, EventArgs e)
        {
            if (cmbPanelLocation.SelectedItem == null)
            {
                MessageBox.Show("Please select a node first.");
                return;
            }
            if (_currentActionControl == _registerControl)
                UpdateActionPanel(null);
            else
            {
                _registerControl = new PanelSettingRegisterIP();
                _registerControl.CalibrationCompleted += ActionControl_CalibrationCompleted;
                _registerControl.SelectedNode = (PanelSettingsModel)cmbPanelLocation.SelectedItem;
                UpdateActionPanel(_registerControl);
            }
        }

        private void btnManualCalibrate_Click(object sender, EventArgs e)
        {
            if (cmbPanelLocation.SelectedItem == null)
            {
                MessageBox.Show("Please select a node first.");
                return;
            }
            if (_currentActionControl == _manualControl)
                UpdateActionPanel(null);
            else
            {
                _manualControl = new PanelSettingManualCalibrate();
                _manualControl.CalibrationCompleted += ActionControl_CalibrationCompleted;
                _manualControl.SelectedNode = (PanelSettingsModel)cmbPanelLocation.SelectedItem;
                UpdateActionPanel(_manualControl);
            }
        }

        private void ActionControl_CalibrationCompleted(object sender, EventArgs e)
        {
            int route = (int)cmbRoute.SelectedItem;
            LoadAssignedNodes(route);
            UpdateActionPanel(null);
        }

        // --------------------- Route & Panel Logic.
        private void cmbRoute_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_updating) return;
            int route = (int)cmbRoute.SelectedItem;
            LoadAssignedNodes(route);
        }

        private void LoadAssignedNodes(int route)
        {
            _assignedNodes = NodeRepository.GetUncalibratedNodesForRoute(route);
            //Debug.WriteLine($"Uncalibrated nodes for route {route}: {_assignedNodes.Count}");

            cmbPanelLocation.DataSource = null;
            cmbPanelLocation.DataSource = _assignedNodes;
            cmbPanelLocation.DisplayMember = "PanelLocation";

            cmbIPAddress.DataSource = null;
            cmbIPAddress.DataSource = _assignedNodes.Select(n => n.IPAddress).ToList();

            if (_assignedNodes.Count == 0)
            {
                cmbPanelLocation.Text = "";
                cmbIPAddress.Text = "";
                txtDescription.Text = "";                // <-- clear Description
                txtPanelSerialNumber.Text = "";          // <-- clear serial number
                return;
            }
            cmbPanelLocation.SelectedIndex = 0;
        }

        private void cmbPanelLocation_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_updating) return;
            if (cmbPanelLocation.SelectedItem == null) return;

            var selected = (PanelSettingsModel)cmbPanelLocation.SelectedItem;
            UpdateIPFromPanelLocation(selected);
        }

        private void cmbIPAddress_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_updating) return;
            if (cmbIPAddress.SelectedItem == null) return;

            string ip = cmbIPAddress.SelectedItem.ToString();
            UpdatePanelLocationFromIP(ip);
        }

        private void UpdatePanelLocationFromIP(string ip)
        {
            var match = _assignedNodes.FirstOrDefault(n => n.IPAddress == ip);
            if (match != null)
            {
                _updating = true;
                cmbPanelLocation.SelectedItem = match;
                txtDescription.Text = match.Description;
                txtPanelSerialNumber.Text = match.PanelSerialNumber.ToString();
                _updating = false;
            }
        }

        private void UpdateIPFromPanelLocation(PanelSettingsModel selected)
        {
            _updating = true;
            cmbIPAddress.Text = selected.IPAddress;
            txtDescription.Text = selected.Description;
            txtPanelSerialNumber.Text = selected.PanelSerialNumber.ToString();
            _updating = false;
        }

        // ------------------ This method: Dispose is handled in the Designer file
        //protected override void Dispose(bool disposing) { }
    }
}