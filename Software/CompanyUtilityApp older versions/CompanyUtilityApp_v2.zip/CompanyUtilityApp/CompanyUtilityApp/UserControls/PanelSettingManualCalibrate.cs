﻿using CompanyUtilityApp.ProgramFiles;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.Ports;
using System.Text;
using System.Text.Json;
using System.Windows.Forms;

namespace CompanyUtilityApp.UserControls
{
    public partial class PanelSettingManualCalibrate : UserControl
    {
        private SerialPort _serialPort;
        [System.ComponentModel.DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public PanelSettingsModel SelectedNode { get; set; }   // set from parent
        public event EventHandler CalibrationCompleted;        // notify parent to refresh list


        public PanelSettingManualCalibrate()
        {
            InitializeComponent();
            LoadComPorts();
        }

        private void LoadComPorts()
        {
            string previous = cmbSerialPort.Text;
            cmbSerialPort.Items.Clear();
            cmbSerialPort.Items.AddRange(SerialPort.GetPortNames());
            if (cmbSerialPort.Items.Count > 0)
            {
                if (!string.IsNullOrEmpty(previous) && cmbSerialPort.Items.Contains(previous))
                    cmbSerialPort.SelectedItem = previous;
                else
                    cmbSerialPort.SelectedIndex = 0;
            }
            btnDeploy.Enabled = true;
        }

        private void btnRefreshPorts_Click(object sender, EventArgs e) => LoadComPorts();

        private void btnConnect_Click(object sender, EventArgs e)
        {
            if (_serialPort != null && _serialPort.IsOpen) return;
            string port = cmbSerialPort.Text;
            if (string.IsNullOrEmpty(port)) { MessageBox.Show("Select a COM port."); return; }

            try
            {
                _serialPort = new SerialPort(port, 115200);
                _serialPort.DataReceived += SerialPort_DataReceived;
                _serialPort.Open();
                btnConnect.Enabled = false;
                btnDisconnect.Enabled = true;
                cmbSerialPort.Enabled = false;
                btnDeploy.Enabled = false;
                AppendToOutput($"Connected to {port}\n");
            }
            catch (Exception ex) { MessageBox.Show($"Failed to open COM port: {ex.Message}"); }
        }

        private void btnDisconnect_Click(object sender, EventArgs e)
        {
            CloseSerialPort();
            btnConnect.Enabled = true;
            btnDisconnect.Enabled = false;
            cmbSerialPort.Enabled = true;
            btnDeploy.Enabled = true;
            AppendToOutput("Disconnected.\n");
        }

        private void CloseSerialPort()
        {
            if (_serialPort != null && _serialPort.IsOpen)
            {
                _serialPort.Close();
                _serialPort.DataReceived -= SerialPort_DataReceived;
                _serialPort = null;
            }
        }

        private void SerialPort_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            if (_serialPort == null || !_serialPort.IsOpen) return;
            string data = _serialPort.ReadExisting();
            if (!string.IsNullOrEmpty(data))
            {
                this.Invoke((MethodInvoker)(() =>
                {
                    txtSerialOutput.AppendText(data);
                    txtSerialOutput.SelectionStart = txtSerialOutput.TextLength;
                    txtSerialOutput.ScrollToCaret();
                }));
            }
        }

        private void AppendToOutput(string text)
        {
            txtSerialOutput.AppendText(text);
            txtSerialOutput.SelectionStart = txtSerialOutput.TextLength;
            txtSerialOutput.ScrollToCaret();
        }

        private bool IsCalibrationValid()
        {
            return decimal.TryParse(txtSens1.Text, out _) &&
                   decimal.TryParse(txtSens2.Text, out _) &&
                   decimal.TryParse(txtCalib.Text, out _);
        }

        private void btnDeploy_Click(object sender, EventArgs e)
        {
            if (SelectedNode == null)
            {
                MessageBox.Show("No node selected."); return;
            }
            if (!IsCalibrationValid())
            {
                MessageBox.Show("Enter valid numeric calibration values.");
                return;
            }

            var payload = new
            {
                Route = SelectedNode.Route,
                PanelLocation = SelectedNode.PanelLocation,
                IPAddress = SelectedNode.IPAddress,
                Description = SelectedNode.Description,
                PanelSerialNumber = SelectedNode.PanelSerialNumber,
                ACS_Sensitivity1 = decimal.Parse(txtSens1.Text),
                ACS_Sensitivity2 = decimal.Parse(txtSens2.Text),
                Battery_Calibration = decimal.Parse(txtCalib.Text),
                Restart = true
            };
            string json = JsonSerializer.Serialize(payload) + "\n";
            SendData(json);
        }

        private void SendData(string data)
        {
            bool needTemporary = (_serialPort == null || !_serialPort.IsOpen);
            SerialPort port = null;
            bool tempPort = false;
            try
            {
                if (needTemporary)
                {
                    if (string.IsNullOrEmpty(cmbSerialPort.Text))
                    {
                        MessageBox.Show("Select a COM port."); return;
                    }
                    port = new SerialPort(cmbSerialPort.Text, 115200);
                    port.Open();
                    tempPort = true;
                }
                else { port = _serialPort; }

                port.Write(data);
                MessageBox.Show("Configuration sent successfully.", "Deploy", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Mark node calibrated
                NodeRepository.MarkCalibrated(SelectedNode.PanelSerialNumber);
                // Notify parent to refresh dropdown
                CalibrationCompleted?.Invoke(this, EventArgs.Empty);
            }
            catch (Exception ex) { MessageBox.Show($"Serial error: {ex.Message}"); }
            finally
            {
                if (tempPort && port != null && port.IsOpen)
                    port.Close();
            }
        }

        // ------------------ This method: Dispose is handled in the Designer file
        //protected override void Dispose(bool disposing) { }
    }
}
