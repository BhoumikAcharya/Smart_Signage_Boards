﻿namespace CompanyUtilityApp.UserControls
{
    partial class PanelSettingManualCalibrate
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                // Close serial port and unhook event
                CloseSerialPort();
                if (components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel2 = new Panel();
            btnRefreshPorts = new Button();
            btnDeploy = new Button();
            cmbSerialPort = new ComboBox();
            txtSens1 = new TextBox();
            txtCalib = new TextBox();
            label8 = new Label();
            txtSens2 = new TextBox();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            grpSerialMonitor = new GroupBox();
            panel5 = new Panel();
            txtSerialOutput = new TextBox();
            panel4 = new Panel();
            btnDisconnect = new Button();
            btnConnect = new Button();
            panel2.SuspendLayout();
            grpSerialMonitor.SuspendLayout();
            panel5.SuspendLayout();
            panel4.SuspendLayout();
            SuspendLayout();
            // 
            // panel2
            // 
            panel2.Controls.Add(btnRefreshPorts);
            panel2.Controls.Add(btnDeploy);
            panel2.Controls.Add(cmbSerialPort);
            panel2.Controls.Add(txtSens1);
            panel2.Controls.Add(txtCalib);
            panel2.Controls.Add(label8);
            panel2.Controls.Add(txtSens2);
            panel2.Controls.Add(label7);
            panel2.Controls.Add(label6);
            panel2.Controls.Add(label5);
            panel2.Dock = DockStyle.Left;
            panel2.Location = new Point(0, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(401, 556);
            panel2.TabIndex = 20;
            // 
            // btnRefreshPorts
            // 
            btnRefreshPorts.Location = new Point(336, 178);
            btnRefreshPorts.Name = "btnRefreshPorts";
            btnRefreshPorts.Size = new Size(28, 29);
            btnRefreshPorts.TabIndex = 19;
            btnRefreshPorts.Text = "⟳";
            btnRefreshPorts.UseVisualStyleBackColor = true;
            btnRefreshPorts.Click += btnRefreshPorts_Click;
            // 
            // btnDeploy
            // 
            btnDeploy.Location = new Point(115, 252);
            btnDeploy.Name = "btnDeploy";
            btnDeploy.Size = new Size(94, 29);
            btnDeploy.TabIndex = 14;
            btnDeploy.Text = "Deploy";
            btnDeploy.UseVisualStyleBackColor = true;
            btnDeploy.Click += btnDeploy_Click;
            // 
            // cmbSerialPort
            // 
            cmbSerialPort.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbSerialPort.FormattingEnabled = true;
            cmbSerialPort.Location = new Point(179, 179);
            cmbSerialPort.Name = "cmbSerialPort";
            cmbSerialPort.Size = new Size(151, 28);
            cmbSerialPort.TabIndex = 18;
            // 
            // txtSens1
            // 
            txtSens1.Location = new Point(205, 35);
            txtSens1.Name = "txtSens1";
            txtSens1.Size = new Size(125, 27);
            txtSens1.TabIndex = 15;
            // 
            // txtCalib
            // 
            txtCalib.Location = new Point(205, 134);
            txtCalib.Name = "txtCalib";
            txtCalib.Size = new Size(125, 27);
            txtCalib.TabIndex = 17;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(35, 38);
            label8.Name = "label8";
            label8.Size = new Size(161, 20);
            label8.TabIndex = 10;
            label8.Text = "ACS Sensitivity Value 1:";
            // 
            // txtSens2
            // 
            txtSens2.Location = new Point(205, 77);
            txtSens2.Name = "txtSens2";
            txtSens2.Size = new Size(125, 27);
            txtSens2.TabIndex = 16;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(35, 80);
            label7.Name = "label7";
            label7.Size = new Size(161, 20);
            label7.TabIndex = 11;
            label7.Text = "ACS Sensitivity Value 2:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(61, 137);
            label6.Name = "label6";
            label6.Size = new Size(136, 20);
            label6.TabIndex = 12;
            label6.Text = "Battery Calibration:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(61, 183);
            label5.Name = "label5";
            label5.Size = new Size(79, 20);
            label5.TabIndex = 13;
            label5.Text = "Serial Port:";
            // 
            // grpSerialMonitor
            // 
            grpSerialMonitor.Controls.Add(panel5);
            grpSerialMonitor.Controls.Add(panel4);
            grpSerialMonitor.Dock = DockStyle.Fill;
            grpSerialMonitor.Location = new Point(401, 0);
            grpSerialMonitor.Name = "grpSerialMonitor";
            grpSerialMonitor.Size = new Size(632, 556);
            grpSerialMonitor.TabIndex = 21;
            grpSerialMonitor.TabStop = false;
            grpSerialMonitor.Text = "Serial Monitor";
            // 
            // panel5
            // 
            panel5.Controls.Add(txtSerialOutput);
            panel5.Dock = DockStyle.Fill;
            panel5.Location = new Point(3, 100);
            panel5.Name = "panel5";
            panel5.Size = new Size(626, 453);
            panel5.TabIndex = 4;
            // 
            // txtSerialOutput
            // 
            txtSerialOutput.Dock = DockStyle.Fill;
            txtSerialOutput.Location = new Point(0, 0);
            txtSerialOutput.Multiline = true;
            txtSerialOutput.Name = "txtSerialOutput";
            txtSerialOutput.ReadOnly = true;
            txtSerialOutput.ScrollBars = ScrollBars.Vertical;
            txtSerialOutput.Size = new Size(626, 453);
            txtSerialOutput.TabIndex = 2;
            // 
            // panel4
            // 
            panel4.Controls.Add(btnDisconnect);
            panel4.Controls.Add(btnConnect);
            panel4.Dock = DockStyle.Top;
            panel4.Location = new Point(3, 23);
            panel4.Name = "panel4";
            panel4.Size = new Size(626, 77);
            panel4.TabIndex = 3;
            // 
            // btnDisconnect
            // 
            btnDisconnect.Enabled = false;
            btnDisconnect.Location = new Point(140, 24);
            btnDisconnect.Name = "btnDisconnect";
            btnDisconnect.Size = new Size(94, 29);
            btnDisconnect.TabIndex = 1;
            btnDisconnect.Text = "Disconnect";
            btnDisconnect.UseVisualStyleBackColor = true;
            btnDisconnect.Click += btnDisconnect_Click;
            // 
            // btnConnect
            // 
            btnConnect.Location = new Point(14, 24);
            btnConnect.Name = "btnConnect";
            btnConnect.Size = new Size(94, 29);
            btnConnect.TabIndex = 0;
            btnConnect.Text = "Connect";
            btnConnect.UseVisualStyleBackColor = true;
            btnConnect.Click += btnConnect_Click;
            // 
            // PanelSettingManualCalibrate
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(grpSerialMonitor);
            Controls.Add(panel2);
            Name = "PanelSettingManualCalibrate";
            Size = new Size(1033, 556);
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            grpSerialMonitor.ResumeLayout(false);
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            panel4.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Panel panel2;
        private Button btnRefreshPorts;
        private Button btnDeploy;
        private ComboBox cmbSerialPort;
        private TextBox txtSens1;
        private TextBox txtCalib;
        private Label label8;
        private TextBox txtSens2;
        private Label label7;
        private Label label6;
        private Label label5;
        private GroupBox grpSerialMonitor;
        private Panel panel5;
        private TextBox txtSerialOutput;
        private Panel panel4;
        private Button btnDisconnect;
        private Button btnConnect;
    }
}
