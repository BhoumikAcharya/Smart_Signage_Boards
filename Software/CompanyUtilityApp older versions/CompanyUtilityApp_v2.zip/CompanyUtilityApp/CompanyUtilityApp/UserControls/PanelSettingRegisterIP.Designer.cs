﻿namespace CompanyUtilityApp.UserControls
{
    partial class PanelSettingRegisterIP
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                // Close serial port and unhook event
                CloseSerialPort();
                if (components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnConnect = new Button();
            panel4 = new Panel();
            btnDisconnect = new Button();
            btnRefresh = new Button();
            btnDeploy = new Button();
            cmbSerialPort = new ComboBox();
            panel5 = new Panel();
            txtSerialOutput = new TextBox();
            grpSerialMonitor = new GroupBox();
            label5 = new Label();
            panel2 = new Panel();
            panel4.SuspendLayout();
            panel5.SuspendLayout();
            grpSerialMonitor.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // btnConnect
            // 
            btnConnect.Location = new Point(14, 24);
            btnConnect.Name = "btnConnect";
            btnConnect.Size = new Size(94, 29);
            btnConnect.TabIndex = 0;
            btnConnect.Text = "Connect";
            btnConnect.UseVisualStyleBackColor = true;
            btnConnect.Click += btnConnect_Click;
            // 
            // panel4
            // 
            panel4.Controls.Add(btnDisconnect);
            panel4.Controls.Add(btnConnect);
            panel4.Dock = DockStyle.Top;
            panel4.Location = new Point(3, 23);
            panel4.Name = "panel4";
            panel4.Size = new Size(491, 77);
            panel4.TabIndex = 3;
            // 
            // btnDisconnect
            // 
            btnDisconnect.Enabled = false;
            btnDisconnect.Location = new Point(140, 24);
            btnDisconnect.Name = "btnDisconnect";
            btnDisconnect.Size = new Size(94, 29);
            btnDisconnect.TabIndex = 1;
            btnDisconnect.Text = "Disconnect";
            btnDisconnect.UseVisualStyleBackColor = true;
            btnDisconnect.Click += btnDisconnect_Click;
            // 
            // btnRefresh
            // 
            btnRefresh.Location = new Point(326, 46);
            btnRefresh.Name = "btnRefresh";
            btnRefresh.Size = new Size(28, 29);
            btnRefresh.TabIndex = 19;
            btnRefresh.Text = "⟳";
            btnRefresh.UseVisualStyleBackColor = true;
            btnRefresh.Click += btnRefresh_Click;
            // 
            // btnDeploy
            // 
            btnDeploy.Location = new Point(105, 120);
            btnDeploy.Name = "btnDeploy";
            btnDeploy.Size = new Size(94, 29);
            btnDeploy.TabIndex = 14;
            btnDeploy.Text = "Deploy";
            btnDeploy.UseVisualStyleBackColor = true;
            btnDeploy.Click += btnDeploy_Click;
            // 
            // cmbSerialPort
            // 
            cmbSerialPort.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbSerialPort.FormattingEnabled = true;
            cmbSerialPort.Location = new Point(169, 47);
            cmbSerialPort.Name = "cmbSerialPort";
            cmbSerialPort.Size = new Size(151, 28);
            cmbSerialPort.TabIndex = 18;
            // 
            // panel5
            // 
            panel5.Controls.Add(txtSerialOutput);
            panel5.Dock = DockStyle.Fill;
            panel5.Location = new Point(3, 100);
            panel5.Name = "panel5";
            panel5.Size = new Size(491, 379);
            panel5.TabIndex = 4;
            // 
            // txtSerialOutput
            // 
            txtSerialOutput.Dock = DockStyle.Fill;
            txtSerialOutput.Location = new Point(0, 0);
            txtSerialOutput.Multiline = true;
            txtSerialOutput.Name = "txtSerialOutput";
            txtSerialOutput.ReadOnly = true;
            txtSerialOutput.ScrollBars = ScrollBars.Vertical;
            txtSerialOutput.Size = new Size(491, 379);
            txtSerialOutput.TabIndex = 2;
            // 
            // grpSerialMonitor
            // 
            grpSerialMonitor.Controls.Add(panel5);
            grpSerialMonitor.Controls.Add(panel4);
            grpSerialMonitor.Dock = DockStyle.Fill;
            grpSerialMonitor.Location = new Point(383, 0);
            grpSerialMonitor.Name = "grpSerialMonitor";
            grpSerialMonitor.Size = new Size(497, 482);
            grpSerialMonitor.TabIndex = 23;
            grpSerialMonitor.TabStop = false;
            grpSerialMonitor.Text = "Serial Monitor";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(51, 51);
            label5.Name = "label5";
            label5.Size = new Size(79, 20);
            label5.TabIndex = 13;
            label5.Text = "Serial Port:";
            // 
            // panel2
            // 
            panel2.Controls.Add(btnRefresh);
            panel2.Controls.Add(btnDeploy);
            panel2.Controls.Add(cmbSerialPort);
            panel2.Controls.Add(label5);
            panel2.Dock = DockStyle.Left;
            panel2.Location = new Point(0, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(383, 482);
            panel2.TabIndex = 22;
            // 
            // PanelSettingRegisterIP
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(grpSerialMonitor);
            Controls.Add(panel2);
            Name = "PanelSettingRegisterIP";
            Size = new Size(880, 482);
            panel4.ResumeLayout(false);
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            grpSerialMonitor.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Button btnConnect;
        private Panel panel4;
        private Button btnDisconnect;
        private Button btnRefresh;
        private Button btnDeploy;
        private ComboBox cmbSerialPort;
        private Panel panel5;
        private TextBox txtSerialOutput;
        private GroupBox grpSerialMonitor;
        private Label label5;
        private Panel panel2;
    }
}
